1. Open and extract the zip folder “group_15_assignment6”
2. Open the “group_15_assignment6.pde”
3. Press run to view simulation
4. Click anywhere on the screen to activate the fireworks (interactive component)
	a. The faster you click, the more fireworks that will appear
