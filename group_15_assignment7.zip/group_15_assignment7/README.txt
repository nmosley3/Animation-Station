1. Open and extract the zip folder “group_15_assignment7”
2. Open the “group_15_assignment.pde”
3. Press run to view simulation
4. Use your keyboard arrows to move the swimmer accordingly. 
	Move the swimmer around the screen to collect coins
	Avoid the sharks (if you intersect with one, you will lose a life) 
	Connect with the sailboats to travel horizontally
	Press the spacebar at any time to pause the game and press enter to resume the game
5. If you win or lose, click the displayed button to play again 
