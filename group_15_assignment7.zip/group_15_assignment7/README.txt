﻿1. Open and extract the zip folder “group_15_assignment7”
2. Open the “group_15_assignment.pde”
3. Press run to view simulation
4. Use your keyboard arrows to move the swimmer accordingly. 
   1. Move the swimmer around the screen to collect coins
   2. Avoid the sharks (if you intersect with one, you will lose a life) 
   3. Connect with the sailboats to travel horizontally
   4. [Space] will pause the game. Press enter to resume.
1. If you win or lose, click the displayed button to play again